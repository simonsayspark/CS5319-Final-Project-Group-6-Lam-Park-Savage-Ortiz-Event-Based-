import { Container, Navbar, Nav, NavDropdown } from 'react-bootstrap';
import { Link } from 'react-router-dom';
import minipaLogo from '../Images/minipaLogo.png';
import 'bootstrap/dist/css/bootstrap.min.css';
import '../App.scss';

const NavAss = () => {

return (
<div className='bg-img'>
<h1 className='text-center'>Assistencia-Tecnica</h1>
</div>
);
};

export default NavAss;