import React, { useState, useEffect } from "react";
import { Container, Row, Col, Button, Image, Card } from 'react-bootstrap';
import { useNavigate, Link, useParams } from "react-router-dom";
// import NavbarComponent from "../NavbarComponent";
import FooterComponent from "../FooterComponent";
import NavAss from "../NavAss";

const RedeAuto = () => {

    return(

<Container className="justify-center">

<h1 className="mt-4 text-center">Redes de Autorizadas</h1>
<p className="text-center">Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do
eiusmod tempor incididunt ut labore et dolore magna aliqua.</p>

</Container>
    );
}

export default RedeAuto;